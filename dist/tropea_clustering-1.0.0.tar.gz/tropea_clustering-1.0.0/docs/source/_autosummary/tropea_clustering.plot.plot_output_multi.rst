tropea\_clustering.plot.plot\_output\_multi
===========================================

.. currentmodule:: tropea_clustering.plot

.. autofunction:: plot_output_multi