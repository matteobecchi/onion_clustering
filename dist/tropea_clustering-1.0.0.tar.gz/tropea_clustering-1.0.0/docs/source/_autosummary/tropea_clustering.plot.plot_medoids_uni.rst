tropea\_clustering.plot.plot\_medoids\_uni
==========================================

.. currentmodule:: tropea_clustering.plot

.. autofunction:: plot_medoids_uni