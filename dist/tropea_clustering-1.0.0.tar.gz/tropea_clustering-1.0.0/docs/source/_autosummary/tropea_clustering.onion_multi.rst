tropea\_clustering.onion\_multi
===============================

.. currentmodule:: tropea_clustering

.. autofunction:: onion_multi