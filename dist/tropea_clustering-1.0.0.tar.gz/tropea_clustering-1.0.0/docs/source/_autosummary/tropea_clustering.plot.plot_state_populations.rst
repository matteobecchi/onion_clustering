tropea\_clustering.plot.plot\_state\_populations
================================================

.. currentmodule:: tropea_clustering.plot

.. autofunction:: plot_state_populations