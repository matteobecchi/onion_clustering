tropea\_clustering.OnionMulti
=============================

.. currentmodule:: tropea_clustering

.. autoclass:: OnionMulti
   :members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~OnionMulti.fit
      ~OnionMulti.fit_predict
      ~OnionMulti.get_params
      ~OnionMulti.set_params
   
   

   
   
   