tropea\_clustering.plot.plot\_one\_trj\_multi
=============================================

.. currentmodule:: tropea_clustering.plot

.. autofunction:: plot_one_trj_multi