tropea\_clustering.plot.plot\_sankey
====================================

.. currentmodule:: tropea_clustering.plot

.. autofunction:: plot_sankey