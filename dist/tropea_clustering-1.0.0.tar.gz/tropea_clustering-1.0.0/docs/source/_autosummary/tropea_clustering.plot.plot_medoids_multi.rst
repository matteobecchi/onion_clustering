tropea\_clustering.plot.plot\_medoids\_multi
============================================

.. currentmodule:: tropea_clustering.plot

.. autofunction:: plot_medoids_multi