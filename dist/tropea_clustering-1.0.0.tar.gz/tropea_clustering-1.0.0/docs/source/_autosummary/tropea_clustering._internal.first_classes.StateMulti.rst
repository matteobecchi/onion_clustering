﻿tropea\_clustering.\_internal.first\_classes.StateMulti
=======================================================

.. currentmodule:: tropea_clustering._internal.first_classes

.. autoclass:: StateMulti
   :members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~StateMulti.get_attributes
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~StateMulti.perc
      ~StateMulti.mean
      ~StateMulti.sigma
      ~StateMulti.area
      ~StateMulti.r_2
      ~StateMulti.axis
   
   