tropea\_clustering.OnionUni
===========================

.. currentmodule:: tropea_clustering

.. autoclass:: OnionUni
   :members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~OnionUni.fit
      ~OnionUni.fit_predict
      ~OnionUni.get_params
      ~OnionUni.set_params
   
   

   
   
   