﻿tropea\_clustering
==================

.. automodule:: tropea_clustering

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
      :toctree:
      :nosignatures:
   
      onion_multi
      onion_uni
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: class.rst
      :nosignatures:
   
      OnionMulti
      OnionUni
   
   

   
   
   



.. rubric:: Modules

.. autosummary::
   :toctree:
   :template: module.rst
   :recursive:

   plot

