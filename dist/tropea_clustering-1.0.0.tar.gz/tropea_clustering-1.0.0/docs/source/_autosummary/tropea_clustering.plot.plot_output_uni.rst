tropea\_clustering.plot.plot\_output\_uni
=========================================

.. currentmodule:: tropea_clustering.plot

.. autofunction:: plot_output_uni