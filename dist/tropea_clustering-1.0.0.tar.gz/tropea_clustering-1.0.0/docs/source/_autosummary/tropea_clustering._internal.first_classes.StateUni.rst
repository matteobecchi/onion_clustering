﻿tropea\_clustering.\_internal.first\_classes.StateUni
=====================================================

.. currentmodule:: tropea_clustering._internal.first_classes

.. autoclass:: StateUni
   :members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~StateUni.get_attributes
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~StateUni.perc
      ~StateUni.mean
      ~StateUni.sigma
      ~StateUni.area
      ~StateUni.r_2
      ~StateUni.peak
      ~StateUni.th_inf
      ~StateUni.th_sup
   
   