Classes
=======

.. autosummary::
  :toctree: _autosummary
  :template: class.rst
  :recursive:

  tropea_clustering._internal.first_classes.StateUni
  tropea_clustering._internal.first_classes.StateMulti
